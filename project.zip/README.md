# Heat 2D Stencil — E1–E5 experiments

C++17, Linux/WSL, CMake + Ninja. `heat_core` contains shared grid, initialization,
FTCS step, validation, benchmark statistics and CSV output. E1, MPI E2 strong
scaling, MPI E3 weak scaling, E4 MPI + OpenMP CPU, and E5 MPI + OpenMP GPU
experiments are implemented.

## Build and run

```bash
cmake -S . -B build/release -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/release
./build/release/stencil_serial
```

Run from repository root; output is `results/raw/e1_serial.csv`.
The full E1 workload is five grids, 500 iterations and 10 repeats per grid;
4096² can take substantial time. The executable updates one compact repeat
counter per grid on stderr; the summary and CSV are written after all grids
finish.
`build/debug` may be used for debugging but must not be used for performance
measurements.

Run E2 strong scaling with `scripts/local/run_e2.sh`. It writes one row per
rank configuration to `results/raw/e2_strong.csv`; the 1-rank configuration
is run first to establish the MPI speedup baseline (and is automatically
included when a subset of rank counts is requested).
Individual repetition samples are used for statistics but are not written to
CSV. The script prints one E1-style summary table after all selected runs.

Run E3 weak scaling with `scripts/local/run_e3.sh [ranks...]`. Supported rank
counts are 1, 4, 16, 64, and 256; the 1-rank baseline is automatically run
first. Each rank owns a fixed 256 x 256 grid, while the global grid scales from
256 x 256 to 4096 x 4096. Spatial spacing, time step, and iteration count are
held fixed. Results are written to `results/raw/e3_weak.csv`.
On Vanda, submit the full E3 job with `qsub scripts/vanda/e3_weak.pbs`.

The E4 CPU experiment is unchanged and is submitted with
`qsub scripts/vanda/e4_hybrid_CPU.pbs`. E5 GPU builds and runs from one PBS job:

After the CPU E4 results exist, submit one E5 job:

```bash
qsub scripts/vanda/e5_hybrid_GPU.pbs
```

The PBS job loads GCC 13.2.0, NVHPC 24.7, OpenMPI 4.1.6 and CMake 3.27.6, then
builds the GPU targets in `build/vanda_gpu/` with NVHPC
`-mp=gpu -gpu=cc86`. Override module names with `GCC_MODULE`, `NVHPC_MODULE`,
`OPENMPI_MODULE`, or `CMAKE_MODULE` if Vanda's module names include toolchain
suffixes. It runs regression and GPU correctness tests before measurements.

The job requests four nodes, 36 CPU cores and one GPU per node. Group A/B/C
uses 1/2/4 nodes and GPUs respectively, while retaining the 15 E4 MPI-rank and
CPU threads-per-rank configurations. Ranks on a node share its GPU at device
index 0. `gpu_thread_limit` (256) is a separate device-kernel setting; CPU
threads-per-rank continue to control host rank placement. Static configuration
checks and runtime rank/node/device checks reject oversubscribed or mismatched
layouts.

The GPU Solver keeps two full grids resident on the GPU for all 500 steps.
Each step packs owned edges into a small device buffer, copies those edges to
the host for the existing MPI halo exchange, copies received halos back, then
launches the FTCS kernel and swaps device-buffer roles. Only setup and the
final result copy transfer complete grids. Solver time includes setup,
iterations, halo synchronization and the final copy. The output also separates
MPI halo, GPU compute/kernel launch, boundary D2H, halo H2D, setup, and final
copy timing; component maxima are diagnostics and must not be added together
as a total runtime.

Before measuring, PBS runs GPU/CPU full-grid comparison tests for odd and even
step counts with one and four MPI ranks. Each production configuration also
compares one complete 4096 x 4096, 500-step GPU result with a CPU OpenMP
reference using the same MPI decomposition; that correctness run is outside
the recorded GPU solver time. The comparison reports maximum absolute and
relative L2 error with fixed tolerances. Every repetition also undergoes
global physical-boundary/temperature validation. Failed configurations are
not written as valid timing results.
The CPU baseline is read from the completed E4 CSV, and output reports both
per-configuration CPU/GPU speedup and GPU group scaling (relative to the
first configuration in that GPU group). GPU solver time includes GPU setup,
boundary/halo transfers, MPI exchange, kernel launch/synchronization and final
copy; E4 solver time does not include GPU transfers, so this is an end-to-end
runtime comparison, not an equal-resource CPU/GPU efficiency comparison.

Results are written to `results/raw/e5_gpu.csv` and
`results/raw/e5_gpu_runs.csv` (15 summary rows and 150 repetition rows). The PBS
job records its ID, allocated nodes and visible GPU model in its standard job
log. Existing E5 CSV files cause the run to stop rather than be overwritten;
move or remove both result files explicitly before starting a fresh run.

## MPI extension contract

- `Grid(nx, ny, halo, global_row, global_col)` owns a local rectangular region.
- `initialize` uses **global** coordinates and sets only owned cells.
- Before `ftcs_step`, exchange one-layer halos with four Cartesian neighbors.
- `ftcs_step` computes only owned, nonphysical-boundary cells; MPI owns the
  communication and the `swap_data` call between steps.
- On global physical boundaries, initialize both buffers consistently; for
  MPI local regions touching a physical boundary, copy those owned boundary
  cells to both buffers before time stepping.
- `validate_local` scans owned cells; aggregate its metrics using MPI reductions.
- Serial and MPI reference comparisons require matching global indexing,
  iteration counts and boundary handling.

The `ftcs_step` kernel is serial by design; E4 CPU and E5 GPU use separate
OpenMP kernels without changing the physical model.
